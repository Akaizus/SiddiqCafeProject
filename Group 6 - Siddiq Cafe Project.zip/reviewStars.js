document.addEventListener("DOMContentLoaded", () => {
    const stars = document.querySelectorAll(".star");
    const ratingText = document.getElementById("rating-text");
    let selectedRating = 0;

    // Add hover and click events to each star
    stars.forEach(star => {
        const value = star.getAttribute("data-value");

        // Highlight stars on hover
        star.addEventListener("mouseover", () => {
            highlightStars(value);
            ratingText.textContent = `Rating: ${value} star${value > 1 ? "s" : ""}`;
        });

        // Remove highlight when not hovering
        star.addEventListener("mouseout", () => {
            highlightStars(selectedRating); // Keep selected stars highlighted
            ratingText.textContent = selectedRating
                ? `Your Rating: ${selectedRating} star${selectedRating > 1 ? "s" : ""}`
                : "Hover over the stars to rate us!";
        });

        // Set the selected rating on click
        star.addEventListener("click", () => {
            selectedRating = value;
            highlightStars(value);
            ratingText.textContent = `Thank you! You rated us ${value} star${value > 1 ? "s" : ""}.`;
        });
    });

    // Function to highlight stars
    function highlightStars(rating) {
        stars.forEach(star => {
            const starValue = star.getAttribute("data-value");
            star.classList.toggle("hovered", starValue <= rating);
            star.classList.toggle("selected", starValue <= selectedRating);
        });
    }
    
});