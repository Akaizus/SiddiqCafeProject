document.getElementById('contactForm').addEventListener('submit', function(event) {
    event.preventDefault();

    const name = document.getElementById('name').value;
    const email = document.getElementById('email').value;
    const message = document.getElementById('message').value;

    const confirmationMessage = document.getElementById('confirmationMessage');
    confirmationMessage.textContent = `Thank you, ${name}! We've received your message: "${message}".`;
    confirmationMessage.style.display = 'block';

    // Clear the form
    document.getElementById('contactForm').reset();
});
