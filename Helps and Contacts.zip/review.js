document.getElementById('reviewForm').addEventListener('submit', function(event) {
    event.preventDefault();

    const name = document.getElementById('name').value;
    const review = document.getElementById('review').value;

    
    const newReview = document.createElement('div');
    newReview.classList.add('review');
    newReview.innerHTML = `<strong>${name}:</strong> <p>${review}</p>`;

    // Clear the form
    document.getElementById('reviewForm').reset();
});